package com.asr.glossarium;

import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.VideoView;

public class VideoReproduksiTumbuhanPakuActivity extends AppCompatActivity {
    //Mendefinisikan variabel

    Button clk, clk1;
    VideoView videoView, videoView1;
    MediaController mediaController, mediaController1;

    private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video_reproduksi_tumbuhan_paku);

        videoView= findViewById(R.id.videoView);
        mediaController=new MediaController(this);
    }

    @Override
    public void onStart() {
        super.onStart();
        videoView.setAlpha(1f);
        String videopath = "android.resource://com.asr.glossarium/"+R.raw.videoplayback4;
        Uri uri = Uri.parse(videopath);
        videoView.setVideoURI(uri);
        videoView.setMediaController(mediaController);
        mediaController.setAnchorView(videoView);
    }

}
