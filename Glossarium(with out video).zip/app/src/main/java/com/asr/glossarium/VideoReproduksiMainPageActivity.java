package com.asr.glossarium;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

public class VideoReproduksiMainPageActivity extends AppCompatActivity {
    //Mendefinisikan variabel

    private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.video_reproduksi_main_page);

        Button btn1 = findViewById(R.id.videoreproduksilumut_button);
        Button btn2 = findViewById(R.id.videoreproduksipembuahangymnospermae_button);
        Button btn3 = findViewById(R.id.videoreproduksiseksualtumbuhanangiospermae_button);
        Button btn4 = findViewById(R.id.videoreproduksitumbuhanpaku);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                //TODO Auto-generated method stub
                Intent pindah = new Intent(VideoReproduksiMainPageActivity.this, VideoReproduksiLumutActivity.class);
                startActivity(pindah);
                //menghubungkan antar activity dengan intent

            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                //TODO Auto-generated method stub
                Intent pindah = new Intent(VideoReproduksiMainPageActivity.this,VideoReproduksiPembuahanGymnopermaeActivity.class);
                startActivity(pindah);
                //menghubungkan antar activity dengan intent
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                //TODO Auto-generated method stub
                Intent pindah = new Intent(VideoReproduksiMainPageActivity.this, VideoReproduksiSeksualPembuahanAngioSpermaeActivity.class);
                startActivity(pindah);
                //menghubungkan antar activity dengan intent
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                //TODO Auto-generated method stub
                Intent pindah = new Intent(VideoReproduksiMainPageActivity.this, VideoReproduksiTumbuhanPakuActivity.class);
                startActivity(pindah);
                //menghubungkan antar activity dengan intent
            }
        });
    }

}
