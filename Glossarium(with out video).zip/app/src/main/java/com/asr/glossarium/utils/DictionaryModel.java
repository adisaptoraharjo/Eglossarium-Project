package com.asr.glossarium.utils;

/**
 * Created by Kurnia on 12/20/2017.
 */


public class DictionaryModel {
    private String id;
    private String namatoko;
    private String deskripsi;
    private String alamat;
    private String daerah;
    private String gambar;



    private String gambar2;


    public DictionaryModel(String id, String namatoko, String deskripsi, String alamat, String daerah, String gambar, String gambar2) {
        this.id = id;
        this.namatoko = namatoko;
        this.deskripsi = deskripsi;
        this.alamat = alamat;
        this.daerah = daerah;
        this.gambar = gambar;
        this.gambar2 = gambar2;
    }

    public String getGambar2() {
        return gambar2;
    }

    public void setGambar2(String gambar2) {
        this.gambar2 = gambar2;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNamatoko() {
        return namatoko;
    }

    public void setNamatoko(String namatoko) {
        this.namatoko = namatoko;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getAlamat() {
        return alamat;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public String getDaerah() {
        return daerah;
    }

    public void setDaerah(String daerah) {
        this.daerah = daerah;
    }

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }


}