package com.asr.glossarium.utils;

/**
 * Created by Parsania Hardik on 03-Jan-17.
 */
public class ImageModel {


    private int image_drawable;

    public int getImage_drawable() {
        return image_drawable;
    }

    public void setImage_drawable(int image_drawable) {
        this.image_drawable = image_drawable;
    }
}
