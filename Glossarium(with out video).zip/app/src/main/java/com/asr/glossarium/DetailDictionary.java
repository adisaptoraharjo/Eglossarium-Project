package com.asr.glossarium;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.asr.glossarium.adapters.Definition_Adapter;
import com.asr.glossarium.utils.DetailModel;
import com.viewpagerindicator.CirclePageIndicator;

import java.util.ArrayList;


public class DetailDictionary extends AppCompatActivity {
    private static ViewPager mPager;
    private static int currentPage = 0;
    private static int NUM_PAGES = 0;
    private ArrayList<DetailModel> imageModelArrayList;

    private String[] myImageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sliderdetail);


        String gambar = getIntent().getStringExtra("GAMBAR");
        String gambar2 = getIntent().getStringExtra("GAMBAR2");
        String toko = getIntent().getStringExtra("NAMATOKO");
        String daerah = getIntent().getStringExtra("DAERAH");
        String alamat = getIntent().getStringExtra("ALAMAT");
        String deskripsi = getIntent().getStringExtra("DESKRIPSI");


        ImageView gambarview = findViewById(R.id.foto);
        TextView tokotext = findViewById(R.id.namadictionarytext);
        TextView daerahtext = findViewById(R.id.daerahtext);
        TextView deskripsitext = findViewById(R.id.deskripsitext);


        //gambarview.setImageBitmap(ImageViaAssets("kalianda"+resID));
        System.out.println(gambar);
//        Picasso.get().load("file:///android_asset/"+daerah+"/"+gambar+".jpg").into(gambarview);

        //gambarview.setImageResource(resID);
        tokotext.setText("Nama : "+ toko);
        deskripsitext.setText("Deskripsi : " + '\n' +deskripsi);


        myImageList = new String[]{gambar, gambar2};
        imageModelArrayList = new ArrayList<>();
        imageModelArrayList = populateList();
        init();


    }


        private ArrayList<DetailModel> populateList(){

        ArrayList<DetailModel> list = new ArrayList<>();
        DetailModel imageModel = new DetailModel();
        for(int i = 0; i < 2; i++){
            imageModel.setImage_drawable(myImageList[i]);
            list.add(imageModel);
        }

        return list;
        }

    private void init() {

        mPager = findViewById(R.id.pager);
        mPager.setAdapter(new Definition_Adapter(DetailDictionary.this,imageModelArrayList));

        CirclePageIndicator indicator = findViewById(R.id.indicator);

        indicator.setViewPager(mPager);

        final float density = getResources().getDisplayMetrics().density;

        //Set circle indicator radius
        indicator.setRadius(3 * density);

        NUM_PAGES =imageModelArrayList.size();


        // Pager listener over indicator
        indicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageSelected(int position) {
                currentPage = position;
            }

            @Override
            public void onPageScrolled(int pos, float arg1, int arg2) {
            }

            @Override
            public void onPageScrollStateChanged(int pos) {

            }
        });


    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id=item.getItemId();
        if(id==android.R.id.home){
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

}
