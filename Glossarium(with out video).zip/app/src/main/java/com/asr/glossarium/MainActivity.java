package com.asr.glossarium;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;


import com.asr.glossarium.utils.DatabaseHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    Button close;
    Dialog MyDialog;
    private int STORAGE_PERMISSION_CODE = 23;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);



        /*
        //fungsi tombol off
        Button dictionary_eglossarium = (Button) findViewById(R.id.btndictionary);
        dictionary_eglossarium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, DictionaryActivity.class));
            }
        });

        Button dictionary_klasifikasi = (Button) findViewById(R.id.btn_kms_klasifikasi);
        dictionary_klasifikasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Sedang Dalam Pengembangan", Toast.LENGTH_SHORT).show();
            }
        });

        Button dictionary_menu3 = (Button) findViewById(R.id.btn_kms_menu3);
        dictionary_menu3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Sedang Dalam Pengembangan", Toast.LENGTH_SHORT).show();
            }
        });

        Button dictionary_menu4 = (Button) findViewById(R.id.btn_kms_menu4);
        dictionary_menu4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Sedang Dalam Pengembangan", Toast.LENGTH_SHORT).show();
            }
        });

        Button dictionary_menu5 = (Button) findViewById(R.id.btn_kms_menu5);
        dictionary_menu5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Sedang Dalam Pengembangan", Toast.LENGTH_SHORT).show();
            }
        });
        */

        requestStoragePermission();

        db = new DatabaseHelper(this);
        File database = getApplicationContext().getDatabasePath(DatabaseHelper.DBNAME);
        if (!database.exists()) {
            db.getReadableDatabase();
            if (copyDatabase(this)){
                Toast.makeText(getApplicationContext(), "Copy success", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "Copy failed", Toast.LENGTH_LONG).show();
                return;
            }
        }

    }

    private void requestStoragePermission(){
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)){

        }

        //And finally ask for the permission
        ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},STORAGE_PERMISSION_CODE);


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        //Checking the request code of our request
        if(requestCode == STORAGE_PERMISSION_CODE){

            //If permission is granted
            if(grantResults.length >0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){

                //Displaying a toast
                //  Toast.makeText(this,"Permission granted now you can read the storage",Toast.LENGTH_LONG).show();
            }else{
                //Displaying another toast if permission is not granted
                //Toast.makeText(this,"Oops you just denied the permission",Toast.LENGTH_LONG).show();
            }}}



    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    // setting in toolbar main disable
    /*
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        }
        return super.onOptionsItemSelected(item);
    }
    */

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_glossarium) {
            startActivity(new Intent(this, DictionaryActivity.class));
        }
        else if (id == R.id.nav_klasifikasi) {
            //Toast.makeText(getApplicationContext(), "Sedang Dalam Pengembangan", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, KlasifikasiActivity.class));
        }
        else if (id == R.id.nav_siklushidup) {
            //Toast.makeText(getApplicationContext(), "Sedang Dalam Pengembangan", Toast.LENGTH_SHORT).show();
            //startActivity(new Intent(this, SliderActivity.class));
            startActivity(new Intent(this, VideoReproduksiMainPageActivity.class));
        }
        else if (id == R.id.nav_profilpembuat) {
            //Toast.makeText(getApplicationContext(), "Sedang Dalam Pengembangan", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, InformasiPembuatActivity.class));
        }
        else if (id == R.id.nav_bantuan) {
            //
            startActivity(new Intent(this, BantuanActivity.class));
        }
        else if (id == R.id.nav_popup) {
            MyCustomAlertDialog();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);


        return true;
    }

    public void MyCustomAlertDialog(){
        MyDialog = new Dialog(MainActivity.this);
        MyDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        MyDialog.setContentView(R.layout.custom_popup);
        MyDialog.setTitle("My Custom Dialog");

        close = MyDialog.findViewById(R.id.close);
        close.setEnabled(true);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDialog.cancel();
            }
        });
        MyDialog.show();
    }




    private boolean copyDatabase(Context context) {
        try {
            InputStream inputStream = context.getAssets().open(DatabaseHelper.DBNAME);
            String outFileName = DatabaseHelper.DBLOCATION + DatabaseHelper.DBNAME;
            OutputStream outputStream = new FileOutputStream(outFileName);
            byte[] buff = new byte[1024];
            int length;
            while ((length = inputStream.read(buff)) > 0) {
                outputStream.write(buff, 0, length);
            }
            outputStream.flush();
            outputStream.close();
            Log.w("Database", "Copy Success");
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}