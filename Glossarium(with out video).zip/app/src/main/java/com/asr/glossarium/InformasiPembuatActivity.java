package com.asr.glossarium;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

public class InformasiPembuatActivity extends AppCompatActivity {
    //Mendefinisikan variabel
    private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.informasi_pembuat);
    }
}
