package com.asr.glossarium.adapters;

import android.content.Context;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;


import com.asr.glossarium.R;
import com.asr.glossarium.utils.DetailModel;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Parsania Hardik on 23/04/2016.
 */
public class Definition_Adapter extends PagerAdapter {


    private ArrayList<DetailModel> imageModelArrayList;
    private LayoutInflater inflater;
    private Context context;

    public Definition_Adapter(Context context, ArrayList<DetailModel> imageModelArrayList) {
        this.context = context;
        this.imageModelArrayList = imageModelArrayList;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public int getCount() {
        return imageModelArrayList.size();
    }

    @Override
    public Object instantiateItem(ViewGroup view, int position) {
        View imageLayout = inflater.inflate(R.layout.detaildictionary, view, false);

        assert imageLayout != null;
        final ImageView imageView = imageLayout.findViewById(R.id.foto);

        Picasso.get().load("file:///android_asset/"+imageModelArrayList.get(position).getImage_drawable()+".jpg").into(imageView);

       // imageView.setImageResource(imageModelArrayList.get(position).getImage_drawable());

        view.addView(imageLayout, 0);

        return imageLayout;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view.equals(object);
    }

    @Override
    public void restoreState(Parcelable state, ClassLoader loader) {
    }

    @Override
    public Parcelable saveState() {
        return null;
    }


}