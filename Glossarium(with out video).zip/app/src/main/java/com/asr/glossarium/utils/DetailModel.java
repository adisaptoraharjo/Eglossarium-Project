package com.asr.glossarium.utils;

public class DetailModel {

    private String image_drawable;

    public String getImage_drawable() {
        return image_drawable;
    }

    public void setImage_drawable(String image_drawable) {
        this.image_drawable = image_drawable;
    }
}
