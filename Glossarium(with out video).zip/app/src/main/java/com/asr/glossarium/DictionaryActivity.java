package com.asr.glossarium;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.widget.Button;

/**
 * Created by Kokoro on 12/21/2017.
 */

import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.widget.Toast;

import com.asr.glossarium.adapters.Word_Adapter;
import com.asr.glossarium.utils.DatabaseHelper;
import com.asr.glossarium.utils.DictionaryModel;

import java.util.List;



public class DictionaryActivity extends AppCompatActivity {

    Button close;
    private RecyclerView rvWord;
    private Word_Adapter word_adapter;
    private List<DictionaryModel> dictionaryModelList;
    private DatabaseHelper mDBHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dictionary_activity);

        rvWord= findViewById(R.id.rvWord);
        rvWord.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        RecyclerView.ItemDecoration itemDecoration=new DividerItemDecoration(getApplicationContext(),DividerItemDecoration.VERTICAL);
        rvWord.addItemDecoration(itemDecoration);

        mDBHelper=new DatabaseHelper(this);

        dictionaryModelList=mDBHelper.getListWord("");

        word_adapter=new Word_Adapter();
        word_adapter.setData(dictionaryModelList);
        rvWord.setAdapter(word_adapter);

        SearchView searchView= findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                searchWord(newText);
                return false;
            }
        });

    }

    private void searchWord(String wordSearch){
        dictionaryModelList.clear();
        dictionaryModelList=mDBHelper.getListWord(wordSearch);
        word_adapter.setData(dictionaryModelList);
        rvWord.setAdapter(word_adapter);
    }



}

