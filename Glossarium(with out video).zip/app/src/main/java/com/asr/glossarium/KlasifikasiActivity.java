package com.asr.glossarium;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.webkit.WebView;

public class KlasifikasiActivity extends AppCompatActivity {
    //Mendefinisikan variabel
    private Toolbar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.klasifikasi);


        WebView webView01 = findViewById(R.id.webview3101);
        webView01.setBackgroundColor(0x00000000);
        String text01 = "Tumbuhan diklasifikasikan menjadi dua nonvaskuler (tumbuhan yang tidak berpembuluh) dan tumbuhan vaskuler (tumbuhan yang berpembuluh)";
        webView01.loadData("<p style=\"text-align: justify\"> "+ text01 +" </p> ", "text/html", "UTF-8");

        WebView webView02 = findViewById(R.id.webview3102);
        webView02.setBackgroundColor(0x00000000);
        String text02 = "Tumbuhan yang tidak berpembuluh merupakan tumbuhan yang tidak memiliki jaringan pembuluh sehingga tidak memiliki jaringan yang berfungsi mengangkut zat makanan, air, dan mineral. Umumnya tumbuhan tidak berpembuluh ini dikenal dengan nama lumut, dikelompokkan ke dalam tiga divisi, yaitu divisi Bryophyta, Hepatophyta dan Anthocerophyta. Tumbuhan berpembuluh sudah memiliki jaringan pembuluh pengangkut. Tumbuhan berpembuluh dikelompokkan menjadi tumbuhan tidak berbiji dan tumbuhan berbiji. Tumbuhan berpembuluh tidak berbiji meliputi semua jenis tumbuhan paku (Pterydophyta). Sedangkan tumbuhan berbiji dikelompokkan menjadi tumbuhan berbiji terbuka (Gymnospermae) dan tumbuhan berbiji tertutup (Angiospermae).";
        webView02.loadData("<p style=\"text-align: justify\"> "+ text02 +" </p> ", "text/html", "UTF-8");

        WebView webView0 = findViewById(R.id.webview3103);
        webView0.setBackgroundColor(0x00000000);
        String text0 = "Lumut dibagi menjadi tiga filum yaitu lumut hati (filum Hepatophyta), lumut tanduk ( filum Anthocerophyta) lumut daun (filum Bryophyta).";
        webView0.loadData("<p style=\"text-align: justify\"> "+ text0 +" </p> ", "text/html", "UTF-8");

        WebView webView = findViewById(R.id.webview3104);
        webView.setBackgroundColor(0x00000000);
        String text = "Klasifikasi paku dibagi menjadi empat filum, yaitu Psilophyta, Lycophyta, Sphenophyta, dan Pterophyta.";
        webView.loadData("<p style=\"text-align: justify\"> "+ text +" </p> ", "text/html", "UTF-8");

        WebView webView2 = findViewById(R.id.webview3105);
        webView2.setBackgroundColor(0x00000000);
        String text2 = "Tumbuhan biji (Spermatophyta) Berdasarkan bentuknya, tumbuhan berbiji dibagi menjadi dua, yaitu gymnospermae (tumbuhan biji terbuka) dan angiospermae (tumbuhan biji tertutup). Tumbuhan gymnospermae dibagi menjadi filum Cycadophyta, filum Ginkgophyta, filum Gnetophyta dan filum Coniferophyta.";
        webView2.loadData("<p style=\"text-align: justify\"> "+ text2 +" </p> ", "text/html", "UTF-8");

        WebView webView3 = findViewById(R.id.webview3106);
        webView3.setBackgroundColor(0x00000000);
        String text3 = "Tumbuhan gymnospermae dibagi menjadi divisi Cycadophyta, divisi Ginkgophyta, divisi Gnetophyta dan divisi Coniferophyta.";
        webView3.loadData("<p style=\"text-align: justify\"> "+ text3 +" </p> ", "text/html", "UTF-8");

        WebView webView4 = findViewById(R.id.webview3107);
        webView4.setBackgroundColor(0x00000000);
        String text4 = "Tumbuhan berbiji tertutup (angiospermae) dibagi menjadi dua, yaitu tumbuhan monokotil (berkeping satu) dan tumbuhan dikotil ( berkeping dua).";
        webView4.loadData("<p style=\"text-align: justify\"> "+ text4 +" </p> ", "text/html", "UTF-8");


    }
}
