package com.asr.glossarium;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.io.InputStream;


public class DefinitionActivity extends AppCompatActivity {

    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_definition);


        String gambar = getIntent().getStringExtra("GAMBAR");
        String toko = getIntent().getStringExtra("NAMATOKO");
        String daerah = getIntent().getStringExtra("DAERAH");
        String alamat = getIntent().getStringExtra("ALAMAT");
        String deskripsi = getIntent().getStringExtra("DESKRIPSI");



        ImageView gambarview = findViewById(R.id.foto);
        TextView tokotext = findViewById(R.id.namadictionarytext);
        TextView daerahtext = findViewById(R.id.daerahtext);
        TextView deskripsitext = findViewById(R.id.deskripsitext);


        //gambarview.setImageBitmap(ImageViaAssets("kalianda"+resID));
        System.out.println(gambar);
        Picasso.get().load("file:///android_asset/"+daerah+"/"+gambar+".jpg").into(gambarview);

        //gambarview.setImageResource(resID);
        tokotext.setText("Nama Dictionary: "+ toko);
        deskripsitext.setText("Deskripsi: " + '\n' +deskripsi);



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id=item.getItemId();
        if(id==android.R.id.home){
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public Bitmap ImageViaAssets(String fileName){

        AssetManager assetmanager = getAssets();
        InputStream is = null;
        try{

            is = assetmanager.open(fileName);
        }catch(IOException e){
            e.printStackTrace();
        }
        Bitmap bitmap = BitmapFactory.decodeStream(is);
        return bitmap;
    }
}
